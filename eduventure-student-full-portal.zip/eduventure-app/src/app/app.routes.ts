import { Routes } from '@angular/router';

export const routes: Routes = [
  { path:'', redirectTo:'student/dashboard', pathMatch:'full' },

  // ── Student Portal ──────────────────────────────────────────
  { path:'student/dashboard',       loadComponent:()=>import('./student/dashboard/dashboard.component').then(m=>m.StudentDashboardComponent) },
  { path:'student/activities',      loadComponent:()=>import('./student/activities/activities.component').then(m=>m.StudentActivitiesComponent) },
  { path:'student/assignments',     loadComponent:()=>import('./student/assignments/assignments.component').then(m=>m.StudentAssignmentsComponent) },
  { path:'student/learning-summary',loadComponent:()=>import('./student/learning-summary/learning-summary.component').then(m=>m.StudentLearningSummaryComponent) },
  { path:'student/attendance',      loadComponent:()=>import('./student/attendance/attendance.component').then(m=>m.StudentAttendancePageComponent) },
  { path:'student/grades',          loadComponent:()=>import('./student/grades/grades.component').then(m=>m.StudentGradesPageComponent) },
  { path:'student/achievements',    loadComponent:()=>import('./student/achievements/achievements.component').then(m=>m.StudentAchievementsComponent) },
  { path:'student/venture-points',  loadComponent:()=>import('./student/venture-points/venture-points.component').then(m=>m.StudentVenturePointsComponent) },
  { path:'student/venture-shop',    loadComponent:()=>import('./student/venture-shop/venture-shop.component').then(m=>m.VentureShopComponent) },
  { path:'student/challenges',      loadComponent:()=>import('./student/challenges/challenges.component').then(m=>m.StudentChallengesComponent) },
  { path:'student/badges',          loadComponent:()=>import('./student/badges/badges.component').then(m=>m.StudentBadgesComponent) },
  { path:'student/messages',        loadComponent:()=>import('./student/messages/messages.component').then(m=>m.StudentMessagesComponent) },
  { path:'student/notifications',   loadComponent:()=>import('./student/notifications/notifications.component').then(m=>m.StudentNotificationsComponent) },
  { path:'student/my-classes',      loadComponent:()=>import('./student/my-classes/my-classes.component').then(m=>m.MyClassesComponent) },
  { path:'student/profile',         loadComponent:()=>import('./student/profile/profile.component').then(m=>m.StudentProfileComponent) },
  { path:'student/settings',        loadComponent:()=>import('./student/settings/settings.component').then(m=>m.StudentSettingsComponent) },

  // ── Parent Portal ──────────────────────────────────────────
  { path:'parent/dashboard',        loadComponent:()=>import('./parent/dashboard/dashboard.component').then(m=>m.ParentDashboardComponent) },
  { path:'parent/my-children',      loadComponent:()=>import('./parent/my-children/my-children.component').then(m=>m.MyChildrenComponent) },
  { path:'parent/attendance',       loadComponent:()=>import('./parent/attendance/attendance.component').then(m=>m.ParentAttendanceComponent) },
  { path:'parent/grades',           loadComponent:()=>import('./parent/grades/grades.component').then(m=>m.ParentGradesComponent) },
  { path:'parent/classes',          loadComponent:()=>import('./parent/classes/classes.component').then(m=>m.ParentClassesComponent) },
  { path:'parent/achievements',     loadComponent:()=>import('./parent/achievements/achievements.component').then(m=>m.ParentAchievementsComponent) },
  { path:'parent/notifications',    loadComponent:()=>import('./parent/notifications/notifications.component').then(m=>m.ParentNotificationsComponent) },
  { path:'parent/messages',         loadComponent:()=>import('./parent/messages/messages.component').then(m=>m.ParentMessagesComponent) },
  { path:'parent/teachers',         loadComponent:()=>import('./parent/teachers/teachers.component').then(m=>m.ParentTeachersComponent) },
  { path:'parent/learning-progress',loadComponent:()=>import('./parent/learning-progress/learning-progress.component').then(m=>m.LearningProgressComponent) },
  { path:'parent/venture-points',   loadComponent:()=>import('./parent/venture-points/venture-points.component').then(m=>m.VenturePointsComponent) },
  { path:'parent/rewards-history',  loadComponent:()=>import('./parent/rewards-history/rewards-history.component').then(m=>m.RewardsHistoryComponent) },
  { path:'parent/settings',         loadComponent:()=>import('./parent/settings/settings.component').then(m=>m.ParentSettingsComponent) },

  // ── Teacher Portal ──────────────────────────────────────────
  { path:'teacher/classes',         loadComponent:()=>import('./teacher/classes/classes.component').then(m=>m.ClassesComponent) },
  { path:'teacher/students',        loadComponent:()=>import('./teacher/students/students.component').then(m=>m.StudentsComponent) },
  { path:'teacher/attendance',      loadComponent:()=>import('./teacher/attendance/attendance.component').then(m=>m.AttendanceComponent) },
  { path:'teacher/grades',          loadComponent:()=>import('./teacher/grades/grades.component').then(m=>m.GradesComponent) },

  { path:'**', redirectTo:'student/dashboard' }
];
